using System;
using System.Collections;
using System.Web;
using System.Xml;
using newtelligence.DasBlog.Runtime;
using newtelligence.DasBlog.Web;
using newtelligence.DasBlog.Web.Core;
using newtelligence.DasBlog.Web.Services;

namespace net.tangrui.DasBlog.Web.Services
{
	public class SiteMapHandler : IHttpHandler
	{
		public SiteMapHandler()
		{
		}

		#region IHttpHandler Members

		public void ProcessRequest(HttpContext context)
		{
			SiteConfig siteConfig = SiteConfig.GetSiteConfig();
			ILoggingDataService loggingService = LoggingDataServiceFactory.GetService(SiteConfig.GetLogPathFromCurrentContext());
			IBlogDataService dataService = BlogDataServiceFactory.GetService(SiteConfig.GetContentPathFromCurrentContext(), loggingService);

			string referrer = context.Request.UrlReferrer != null ? context.Request.UrlReferrer.AbsoluteUri : String.Empty;
			if (ReferralBlackList.IsBlockedReferrer(referrer)) 
			{
				if (siteConfig.EnableReferralUrlBlackList404s)
				{
					context.Response.StatusCode = 404;
					context.Response.End();
					return;
				}
			}
			else
			{
				loggingService.AddReferral(
					new LogDataItem(
						context.Request.RawUrl,
						referrer,
						context.Request.UserAgent
					)
				);
			}

			CategoryCacheEntryCollection categories = dataService.GetCategories();
			
			EntryCollection allEntries = new EntryCollection();
			EntryCollection entriesInThisCategory;
			foreach (CategoryCacheEntry category in categories)
			{				
				entriesInThisCategory = dataService.GetEntriesForCategory(category.Name, null);
				foreach (Entry entry in entriesInThisCategory)
				{
					if (entry.IsPublic && !allEntries.Contains(entry))
					{
						allEntries.Add(entry);
					}
				}
			}
			allEntries.Sort(new EntrySorter());

			context.Response.ContentType = "text/xml";

			XmlTextWriter xw = new XmlTextWriter(context.Response.Output);
			xw.Formatting = Formatting.Indented;

			xw.Namespaces = true;
			xw.WriteStartDocument();
			xw.WriteStartElement("urlset", "http://www.google.com/schemas/sitemap/0.84");

			// homepage
			xw.WriteStartElement("url");

			xw.WriteElementString("loc", siteConfig.Root);
			xw.WriteElementString("priority", "1.0");
			xw.WriteElementString("changefreq", "daily");

			xw.WriteEndElement(); // url

			// entries
			string permaLinkUrl;
			foreach (Entry entry in allEntries)
			{
				xw.WriteStartElement("url");

				permaLinkUrl = Utils.GetPermaLinkUrl(siteConfig, entry);
				if (!permaLinkUrl.EndsWith("/"))
				{
					permaLinkUrl += "/";
				}
				xw.WriteElementString("loc", permaLinkUrl);
				xw.WriteElementString("lastmod", FormatLastMod(entry.ModifiedLocalTime));
				xw.WriteElementString("changefreq", "weekly");
				xw.WriteElementString("priority", "0.5");

				xw.WriteEndElement(); // url
			}

			xw.WriteEndElement(); // urlset
			xw.WriteEndDocument(); // document

			xw.Close();
		}

		public bool IsReusable
		{
			get
			{
				return true;
			}
		}

		private string FormatLastMod(DateTime date)
		{
			return string.Format("{0:yyyy-MM-ddTHH:mm:ss+00:00}", date.ToUniversalTime());
		}

		#endregion
	}
}
